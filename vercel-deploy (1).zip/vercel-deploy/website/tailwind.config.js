/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#070b16',
          900: '#0b1224',
          800: '#121a33',
          700: '#1a2447',
        },
        accent: {
          DEFAULT: '#7c5cff',
          soft: '#a78bfa',
          glow: '#c4b5fd',
        },
        gold: {
          DEFAULT: '#f5c518',
          dim: '#c9a227',
        },
        pitch: {
          DEFAULT: '#0f9d58',
          dark: '#0b7a44',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        body: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 0 40px rgba(124, 92, 255, 0.35)',
        card: '0 20px 50px rgba(0,0,0,0.45)',
      },
      backgroundImage: {
        'hero-grid':
          'radial-gradient(ellipse 80% 50% at 50% -20%, rgba(124,92,255,0.25), transparent), radial-gradient(ellipse 60% 40% at 100% 0%, rgba(245,197,24,0.08), transparent)',
      },
    },
  },
  plugins: [],
}
