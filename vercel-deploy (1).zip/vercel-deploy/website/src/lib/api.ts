/** API base — loaded dynamically from the server when possible */
let API_BASE = (import.meta as any).env?.VITE_API_URL ?? ''

let apiBaseReady: Promise<string> | null = null

async function ensureApiBase(): Promise<string> {
  if (API_BASE) return API_BASE

  if (!apiBaseReady) {
    apiBaseReady = (async () => {
      try {
        // Try relative first (works if frontend is served from same origin)
        const res = await fetch('/api/public-url')
        if (res.ok) {
          const data = await res.json()
          if (data.url) {
            API_BASE = data.url
            console.log('Loaded API base from server:', API_BASE)
            return API_BASE
          }
        }
      } catch (e) {
        console.warn('Could not load public URL from /api/public-url', e)
      }
      return API_BASE
    })()
  }
  return apiBaseReady
}

export type SessionPayload = {
  sub: string
  username?: string
  avatar?: string | null
  exp?: number
}

export type MeResponse = {
  user_id: string
  footcoins: number
  packs: Record<string, number>
  picks: Record<string, number>
  blind_picks: number
  total_cards: number
  unique_cards: number
  last_pack_open: number
  last_daily_claim: number
  pack_cooldown_seconds: number
}

export type CardItem = {
  footballer_id: string
  name: string
  special: string
  rarity?: number
  nationality?: string
  obtained_at?: string
  image_url: string
}

export type ActivityItem = {
  id: number
  kind: string
  summary: string
  meta?: Record<string, unknown> | null
  created_at: number
}

function token(): string | null {
  return localStorage.getItem('fd_session')
}

export function setSession(t: string) {
  localStorage.setItem('fd_session', t)
}

export function clearSession() {
  localStorage.removeItem('fd_session')
}

export function parseSession(): SessionPayload | null {
  const t = token()
  if (!t) return null
  try {
    const payload = JSON.parse(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')))
    if (payload.exp && payload.exp * 1000 < Date.now()) {
      clearSession()
      return null
    }
    return payload
  } catch {
    return null
  }
}

async function request<T>(path: string, opts: RequestInit = {}): Promise<T> {
  const base = await ensureApiBase()
  const headers: Record<string, string> = {
    ...(opts.headers as Record<string, string> | undefined),
  }
  const t = token()
  if (t) headers['Authorization'] = `Bearer ${t}`
  if (opts.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json'
  }
  const res = await fetch(`${base}${path}`, { ...opts, headers })
  if (!res.ok) {
    let msg = res.statusText
    try {
      const j = await res.json()
      msg = j.detail || j.message || JSON.stringify(j)
    } catch { /* ignore */ }
    throw new Error(typeof msg === 'string' ? msg : 'Request failed')
  }
  if (res.status === 204) return undefined as T
  const ct = res.headers.get('content-type') || ''
  if (ct.includes('application/json')) return res.json()
  return res as unknown as T
}

export const api = {
  health: () => request<{ status: string; db_found: boolean }>('/api/health'),
  stats: () =>
    request<{
      total_users: number
      total_cards_owned: number
      total_specials_owned: number
      total_footcoins_in_circulation: number
      catalog_size: number
    }>('/api/stats'),
  packs: () => request<Record<string, { price: number; rarity_boost: number }>>('/api/packs'),
  picks: () => request<Record<string, { price: number; rarity_boost: number }>>('/api/picks'),
  me: () => request<MeResponse>('/api/auth/me'),
  inventory: (params: { limit?: number; offset?: number; search?: string; special?: string } = {}) => {
    const q = new URLSearchParams()
    if (params.limit) q.set('limit', String(params.limit))
    if (params.offset) q.set('offset', String(params.offset))
    if (params.search) q.set('search', params.search)
    if (params.special) q.set('special', params.special)
    return request<{ total: number; items: CardItem[] }>(`/api/me/inventory?${q}`)
  },
  activities: (limit = 40) =>
    request<{ items: ActivityItem[] }>(`/api/me/activities?limit=${limit}`),
  catalog: (params: { search?: string; limit?: number; offset?: number } = {}) => {
    const q = new URLSearchParams()
    if (params.search) q.set('search', params.search)
    if (params.limit) q.set('limit', String(params.limit))
    if (params.offset) q.set('offset', String(params.offset))
    return request<{ total: number; items: any[] }>(`/api/catalog?${q}`)
  },
  leaderboardCoins: () =>
    request<{ leaderboard: { user_id: string; footcoins: number }[] }>('/api/leaderboard/coins'),
  leaderboardCards: () =>
    request<{ leaderboard: { user_id: string; card_count: number }[] }>('/api/leaderboard/cards'),
  openPack: (pack_type: string, amount = 1) =>
    request<{
      opened: number
      pack_type: string
      cards: CardItem[]
      cooldown_seconds: number
    }>('/api/packs/open', {
      method: 'POST',
      body: JSON.stringify({ pack_type, amount }),
    }),
  buyPack: (pack_type: string, amount = 1) =>
    request<{ bought: number; pack_type: string; spent: number; new_balance: number }>(
      '/api/packs/buy',
      { method: 'POST', body: JSON.stringify({ pack_type, amount }) }
    ),
  packCooldown: () =>
    request<{ cooldown_remaining_seconds: number }>('/api/packs/cooldown'),
  claimDaily: () =>
    request<{ reward: number; new_balance: number }>('/api/economy/daily', { method: 'POST' }),
  dailyStatus: () =>
    request<{ can_claim: boolean; cooldown_remaining_seconds: number }>(
      '/api/economy/daily/status'
    ),
  sellCard: (footballer: string) =>
    request<{ footballer_id: string; name: string; sold_for: number; new_balance: number }>(
      '/api/economy/sell',
      { method: 'POST', body: JSON.stringify({ footballer }) }
    ),
  cardImageUrl: (id: string, special?: string) => {
    const base = `${API_BASE}/api/card-image/${encodeURIComponent(id)}`
    return special && special !== 'Base' ? `${base}?special=${encodeURIComponent(special)}` : base
  },
  loginUrl: () => `${API_BASE}/api/auth/discord/login`,
}