import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import {
  api,
  clearSession,
  MeResponse,
  parseSession,
  SessionPayload,
  setSession,
} from '../lib/api'

type AuthState = {
  session: SessionPayload | null
  me: MeResponse | null
  loading: boolean
  error: string | null
  login: () => void
  logout: () => void
  refresh: () => Promise<void>
}

const AuthCtx = createContext<AuthState | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSessionState] = useState<SessionPayload | null>(() => parseSession())
  const [me, setMe] = useState<MeResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const refresh = useCallback(async () => {
    const s = parseSession()
    setSessionState(s)
    if (!s) {
      setMe(null)
      setLoading(false)
      return
    }
    try {
      const profile = await api.me()
      setMe(profile)
      setError(null)
    } catch (e: any) {
      setError(e.message || 'Session expired')
      clearSession()
      setSessionState(null)
      setMe(null)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const hash = window.location.hash || ''
    if (hash.startsWith('#session=')) {
      const t = decodeURIComponent(hash.slice('#session='.length))
      setSession(t)
      window.history.replaceState(null, '', window.location.pathname + window.location.search)
    }
    const params = new URLSearchParams(window.location.search)
    if (params.get('login_error')) {
      setError(`Login failed: ${params.get('login_error')}`)
      window.history.replaceState(null, '', window.location.pathname)
    }
    refresh()
  }, [refresh])

  const login = () => {
    window.location.href = api.loginUrl()
  }

  const logout = () => {
    clearSession()
    setSessionState(null)
    setMe(null)
  }

  const value = useMemo(
    () => ({ session, me, loading, error, login, logout, refresh }),
    [session, me, loading, error, login, logout, refresh]
  )

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthCtx)
  if (!ctx) throw new Error('useAuth outside provider')
  return ctx
}
