import { Link } from 'react-router-dom'
import { ArrowRight, Shield, Sparkles, Zap } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'

export default function Landing() {
  const { session, login } = useAuth()

  return (
    <div className="animate-in">
      <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-hero-grid px-6 py-16 sm:px-12">
        <div className="relative z-10 max-w-2xl">
          <div className="chip mb-4 border-accent/30 bg-accent/10 text-accent-glow">
            Live sync with Discord
          </div>
          <h1 className="font-display text-4xl font-bold leading-tight tracking-tight sm:text-5xl">
            Your Football DEX,{' '}
            <span className="bg-gradient-to-r from-accent-soft to-gold bg-clip-text text-transparent">
              everywhere
            </span>
          </h1>
          <p className="mt-4 text-lg text-white/65">
            Log in with Discord once. Open packs, claim dailies, manage inventory, and watch the same
            FootCoins and cards update in the bot — one shared database, zero drift.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            {session ? (
              <Link to="/app" className="btn-primary">
                Open dashboard <ArrowRight size={18} />
              </Link>
            ) : (
              <button onClick={login} className="btn-primary">
                Login with Discord <ArrowRight size={18} />
              </button>
            )}
            <Link to="/app/catalog" className="btn-ghost">
              Browse catalog
            </Link>
          </div>
        </div>
        <div className="pointer-events-none absolute -right-10 top-10 h-64 w-64 rounded-full bg-accent/20 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 right-20 h-40 w-40 rounded-full bg-gold/20 blur-3xl" />
      </section>

      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        {[
          {
            icon: Shield,
            title: 'Secure Discord OAuth',
            body: 'Your Discord ID is the only identity. Write actions require a signed session JWT.',
          },
          {
            icon: Zap,
            title: 'Shared game state',
            body: 'Packs, cooldowns, daily rewards, and inventory live in the same SQLite DB as the bot.',
          },
          {
            icon: Sparkles,
            title: 'Premium card art',
            body: 'Card images render from the same Pillow pipeline used in Discord reveals.',
          },
        ].map(({ icon: Icon, title, body }) => (
          <div key={title} className="glass rounded-2xl p-6">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent-glow">
              <Icon size={20} />
            </div>
            <h3 className="font-display font-semibold">{title}</h3>
            <p className="mt-2 text-sm text-white/55">{body}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
