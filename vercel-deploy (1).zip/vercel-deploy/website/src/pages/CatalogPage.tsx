import { useEffect, useState } from 'react'
import { Search } from 'lucide-react'
import { api } from '../lib/api'

export default function CatalogPage() {
  const [items, setItems] = useState<any[]>([])
  const [total, setTotal] = useState(0)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const t = setTimeout(async () => {
      setLoading(true)
      try {
        const r = await api.catalog({ search: search || undefined, limit: 60 })
        setItems(r.items)
        setTotal(r.total)
      } finally {
        setLoading(false)
      }
    }, 250)
    return () => clearTimeout(t)
  }, [search])

  return (
    <div className="space-y-6 animate-in">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="section-title">Catalog</h1>
          <p className="mt-1 text-white/50">{total.toLocaleString()} footballers in the dex</p>
        </div>
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search footballers…"
            className="rounded-xl border border-white/15 bg-navy-900 py-2 pl-9 pr-3 text-sm"
          />
        </div>
      </div>

      {loading ? (
        <p className="text-white/40">Loading…</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {items.map((c) => (
            <div key={c.id} className="glass overflow-hidden rounded-xl">
              <img
                src={api.cardImageUrl(c.id)}
                alt={c.name}
                className="aspect-[1414/2000] w-full object-cover"
                loading="lazy"
              />
              <div className="p-3">
                <div className="truncate text-sm font-semibold">{c.name}</div>
                <div className="text-xs text-white/50">
                  {c.nationality || '—'} · R {c.rarity}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
