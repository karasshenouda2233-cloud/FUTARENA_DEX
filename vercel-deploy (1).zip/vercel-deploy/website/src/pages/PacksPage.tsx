import { useEffect, useState } from 'react'
import { Package, ShoppingCart, Sparkles } from 'lucide-react'
import { api, CardItem } from '../lib/api'
import { useAuth } from '../hooks/useAuth'

export default function PacksPage() {
  const { me, refresh } = useAuth()
  const [catalog, setCatalog] = useState<Record<string, { price: number; rarity_boost: number }>>({})
  const [selected, setSelected] = useState('Basic Pack')
  const [amount, setAmount] = useState(1)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [pulled, setPulled] = useState<CardItem[]>([])

  useEffect(() => {
    api.packs().then((p) => {
      setCatalog(p)
      const first = Object.keys(p)[0]
      if (first) setSelected(first)
    })
  }, [])

  async function buy() {
    setBusy(true)
    setError(null)
    try {
      await api.buyPack(selected, amount)
      await refresh()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function open() {
    setBusy(true)
    setError(null)
    setPulled([])
    try {
      const r = await api.openPack(selected, amount)
      setPulled(r.cards)
      await refresh()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const owned = me?.packs?.[selected] ?? 0
  const price = (catalog[selected]?.price ?? 0) * amount

  return (
    <div className="space-y-8 animate-in">
      <div>
        <h1 className="section-title">Packs</h1>
        <p className="mt-1 text-white/50">
          Buy & open packs with the same odds and 3‑minute cooldown as Discord.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Object.entries(catalog).map(([name, info]) => (
          <button
            key={name}
            onClick={() => setSelected(name)}
            className={`glass rounded-2xl p-5 text-left transition ${
              selected === name ? 'ring-2 ring-accent shadow-glow' : 'hover:bg-white/10'
            }`}
          >
            <div className="mb-2 flex items-center justify-between">
              <Package className="text-accent-soft" size={20} />
              <span className="chip">{me?.packs?.[name] ?? 0} owned</span>
            </div>
            <div className="font-display font-semibold">{name}</div>
            <div className="mt-1 text-sm text-gold">{info.price.toLocaleString()} FC</div>
            <div className="mt-1 text-xs text-white/40">Boost ×{info.rarity_boost}</div>
          </button>
        ))}
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <label className="text-xs text-white/50">Amount (1–100)</label>
            <input
              type="number"
              min={1}
              max={100}
              value={amount}
              onChange={(e) => setAmount(Math.max(1, Math.min(100, Number(e.target.value) || 1)))}
              className="mt-1 block w-24 rounded-xl border border-white/15 bg-navy-900 px-3 py-2"
            />
          </div>
          <button className="btn-primary" disabled={busy} onClick={buy}>
            <ShoppingCart size={16} /> Buy for {price.toLocaleString()} FC
          </button>
          <button className="btn-ghost" disabled={busy || owned < amount} onClick={open}>
            <Sparkles size={16} /> Open {amount}× ({owned} owned)
          </button>
        </div>
        {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
      </div>

      {pulled.length > 0 && (
        <div>
          <h2 className="mb-4 font-display text-lg font-semibold">You pulled</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {pulled.map((c, i) => (
              <div key={`${c.footballer_id}-${i}`} className="glass overflow-hidden rounded-xl">
                <img
                  src={api.cardImageUrl(c.footballer_id, c.special)}
                  alt={c.name}
                  className="aspect-[1414/2000] w-full object-cover"
                  loading="lazy"
                />
                <div className="p-3">
                  <div className="truncate text-sm font-semibold">{c.name}</div>
                  <div className="text-xs text-white/50">
                    {c.special !== 'Base' ? c.special : `Rarity ${c.rarity}`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
