import { useEffect, useState } from 'react'
import { api, ActivityItem } from '../lib/api'

export default function ActivityPage() {
  const [items, setItems] = useState<ActivityItem[]>([])

  useEffect(() => {
    api.activities(80).then((r) => setItems(r.items)).catch(() => {})
  }, [])

  return (
    <div className="space-y-6 animate-in">
      <div>
        <h1 className="section-title">Activity</h1>
        <p className="mt-1 text-white/50">
          Pack opens, buys, daily claims, and sells from both the website and Discord.
        </p>
      </div>
      <div className="glass divide-y divide-white/5 rounded-2xl">
        {items.length === 0 && (
          <p className="p-6 text-sm text-white/40">No activity recorded yet.</p>
        )}
        {items.map((a) => (
          <div key={a.id} className="flex flex-wrap items-start gap-3 px-5 py-4">
            <span className="chip capitalize">{a.kind.replace(/_/g, ' ')}</span>
            <div className="min-w-0 flex-1">
              <p className="text-sm text-white/85">{a.summary}</p>
              <p className="mt-1 text-xs text-white/35">
                {new Date(a.created_at * 1000).toLocaleString()}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
