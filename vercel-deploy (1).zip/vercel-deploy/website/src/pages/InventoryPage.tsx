import { useEffect, useState } from 'react'
import { Search, Trash2 } from 'lucide-react'
import { api, CardItem } from '../lib/api'
import { useAuth } from '../hooks/useAuth'

export default function InventoryPage() {
  const { refresh } = useAuth()
  const [items, setItems] = useState<CardItem[]>([])
  const [total, setTotal] = useState(0)
  const [search, setSearch] = useState('')
  const [special, setSpecial] = useState('all')
  const [loading, setLoading] = useState(true)
  const [msg, setMsg] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    try {
      const r = await api.inventory({
        limit: 200,
        search: search || undefined,
        special: special === 'all' ? undefined : special,
      })
      setItems(r.items)
      setTotal(r.total)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const t = setTimeout(load, 200)
    return () => clearTimeout(t)
  }, [search, special])

  async function sell(c: CardItem) {
    if (!confirm(`Sell ${c.name} (${c.special})?`)) return
    setMsg(null)
    try {
      const r = await api.sellCard(c.footballer_id)
      setMsg(`Sold ${r.name} for ${r.sold_for} FC`)
      await refresh()
      await load()
    } catch (e: any) {
      setMsg(e.message)
    }
  }

  return (
    <div className="space-y-6 animate-in">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="section-title">Inventory</h1>
          <p className="mt-1 text-white/50">{total} cards · shared with Discord</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name…"
              className="rounded-xl border border-white/15 bg-navy-900 py-2 pl-9 pr-3 text-sm"
            />
          </div>
          <select
            value={special}
            onChange={(e) => setSpecial(e.target.value)}
            className="rounded-xl border border-white/15 bg-navy-900 px-3 py-2 text-sm"
          >
            {['all', 'Base', 'Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Sapphire', 'Amethyst', 'Emerald', 'Shiny'].map(
              (s) => (
                <option key={s} value={s}>
                  {s === 'all' ? 'All variants' : s}
                </option>
              )
            )}
          </select>
        </div>
      </div>

      {msg && <p className="text-sm text-accent-glow">{msg}</p>}

      {loading ? (
        <p className="text-white/40">Loading…</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {items.map((c, i) => (
            <div key={`${c.footballer_id}-${c.special}-${i}`} className="glass group overflow-hidden rounded-xl">
              <img
                src={api.cardImageUrl(c.footballer_id, c.special)}
                alt={c.name}
                className="aspect-[1414/2000] w-full object-cover"
                loading="lazy"
              />
              <div className="p-3">
                <div className="truncate text-sm font-semibold">{c.name}</div>
                <div className="flex items-center justify-between text-xs text-white/50">
                  <span>{c.special}</span>
                  <span>{c.rarity}</span>
                </div>
                <button
                  onClick={() => sell(c)}
                  className="mt-2 flex w-full items-center justify-center gap-1 rounded-lg border border-white/10 py-1.5 text-xs text-white/60 opacity-0 transition group-hover:opacity-100 hover:bg-red-500/20 hover:text-red-300"
                >
                  <Trash2 size={12} /> Sell
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
