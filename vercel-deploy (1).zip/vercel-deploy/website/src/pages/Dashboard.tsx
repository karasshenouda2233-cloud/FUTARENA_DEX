import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Coins, Package, Layers, Gift, Clock, Activity } from 'lucide-react'
import { api, ActivityItem } from '../lib/api'
import { useAuth } from '../hooks/useAuth'

function fmtTime(sec: number) {
  if (sec <= 0) return 'Ready'
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = Math.floor(sec % 60)
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}

export default function Dashboard() {
  const { me, refresh } = useAuth()
  const [daily, setDaily] = useState<{ can_claim: boolean; cooldown_remaining_seconds: number } | null>(
    null
  )
  const [activities, setActivities] = useState<ActivityItem[]>([])
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)

  useEffect(() => {
    api.dailyStatus().then(setDaily).catch(() => {})
    api.activities(8).then((r) => setActivities(r.items)).catch(() => {})
  }, [me])

  async function claimDaily() {
    setBusy(true)
    setMsg(null)
    try {
      const r = await api.claimDaily()
      setMsg(`+${r.reward} FootCoins · balance ${r.new_balance.toLocaleString()}`)
      await refresh()
      setDaily(await api.dailyStatus())
      setActivities((await api.activities(8)).items)
    } catch (e: any) {
      setMsg(e.message)
    } finally {
      setBusy(false)
    }
  }

  if (!me) return null

  const packTotal = Object.values(me.packs || {}).reduce((a, b) => a + b, 0)
  const pickTotal =
    Object.values(me.picks || {}).reduce((a, b) => a + b, 0) + (me.blind_picks || 0)

  return (
    <div className="space-y-8 animate-in">
      <div>
        <h1 className="section-title">Dashboard</h1>
        <p className="mt-1 text-white/50">Everything mirrors your Discord account in real time.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'FootCoins', value: me.footcoins.toLocaleString(), icon: Coins, tint: 'text-gold' },
          { label: 'Cards', value: me.total_cards, icon: Layers, tint: 'text-accent-soft' },
          { label: 'Unique', value: me.unique_cards, icon: Layers, tint: 'text-pitch' },
          { label: 'Packs / Picks', value: `${packTotal} / ${pickTotal}`, icon: Package, tint: 'text-white' },
        ].map(({ label, value, icon: Icon, tint }) => (
          <div key={label} className="glass rounded-2xl p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/50">{label}</span>
              <Icon size={18} className={tint} />
            </div>
            <div className="mt-2 font-display text-2xl font-semibold">{value}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="glass rounded-2xl p-6">
          <div className="mb-4 flex items-center gap-2">
            <Gift className="text-gold" size={20} />
            <h2 className="font-display text-lg font-semibold">Daily reward</h2>
          </div>
          <p className="text-sm text-white/55">
            Claim 100 FootCoins every 24 hours. Cooldown is shared with the Discord bot.
          </p>
          <div className="mt-4 flex items-center gap-3">
            <button
              className="btn-primary"
              disabled={busy || (daily ? !daily.can_claim : false)}
              onClick={claimDaily}
            >
              {daily?.can_claim === false
                ? `Wait ${fmtTime(daily.cooldown_remaining_seconds)}`
                : 'Claim daily'}
            </button>
            <div className="flex items-center gap-1.5 text-sm text-white/45">
              <Clock size={14} />
              Pack CD: {fmtTime(me.pack_cooldown_seconds)}
            </div>
          </div>
          {msg && <p className="mt-3 text-sm text-accent-glow">{msg}</p>}
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity size={20} className="text-accent-soft" />
              <h2 className="font-display text-lg font-semibold">Recent activity</h2>
            </div>
            <Link to="/app/activity" className="text-sm text-accent-soft hover:underline">
              View all
            </Link>
          </div>
          <ul className="space-y-3">
            {activities.length === 0 && (
              <li className="text-sm text-white/40">No activity yet — open a pack or claim daily.</li>
            )}
            {activities.map((a) => (
              <li key={a.id} className="flex gap-3 text-sm">
                <span className="chip shrink-0 capitalize">{a.kind.replace('_', ' ')}</span>
                <span className="text-white/70">{a.summary}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <Link to="/app/packs" className="btn-primary">
          <Package size={16} /> Open packs
        </Link>
        <Link to="/app/inventory" className="btn-ghost">
          <Layers size={16} /> Inventory
        </Link>
      </div>
    </div>
  )
}
