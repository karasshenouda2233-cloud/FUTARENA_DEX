import { useEffect, useState } from 'react'
import { api } from '../lib/api'

export default function LeaderboardPage() {
  const [coins, setCoins] = useState<{ user_id: string; footcoins: number }[]>([])
  const [cards, setCards] = useState<{ user_id: string; card_count: number }[]>([])

  useEffect(() => {
    api.leaderboardCoins().then((r) => setCoins(r.leaderboard)).catch(() => {})
    api.leaderboardCards().then((r) => setCards(r.leaderboard)).catch(() => {})
  }, [])

  return (
    <div className="space-y-8 animate-in">
      <div>
        <h1 className="section-title">Leaderboards</h1>
        <p className="mt-1 text-white/50">Live ranks from the shared bot database.</p>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Board title="Top FootCoins" rows={coins.map((r) => ({ id: r.user_id, value: r.footcoins.toLocaleString() }))} />
        <Board title="Most cards" rows={cards.map((r) => ({ id: r.user_id, value: r.card_count.toLocaleString() }))} />
      </div>
    </div>
  )
}

function Board({ title, rows }: { title: string; rows: { id: string; value: string }[] }) {
  return (
    <div className="glass rounded-2xl p-6">
      <h2 className="mb-4 font-display text-lg font-semibold">{title}</h2>
      <ol className="space-y-2">
        {rows.map((r, i) => (
          <li
            key={r.id}
            className="flex items-center justify-between rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2 text-sm"
          >
            <span className="flex items-center gap-3">
              <span className="w-6 text-center font-semibold text-white/40">{i + 1}</span>
              <span className="font-mono text-white/80">{r.id}</span>
            </span>
            <span className="font-semibold text-gold">{r.value}</span>
          </li>
        ))}
        {rows.length === 0 && <li className="text-white/40">No data yet</li>}
      </ol>
    </div>
  )
}
