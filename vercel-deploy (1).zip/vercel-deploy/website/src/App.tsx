import { NavLink, Route, Routes } from 'react-router-dom'
import {
  LayoutDashboard,
  Package,
  Layers,
  BookOpen,
  Trophy,
  Activity,
  LogIn,
  LogOut,
  Coins,
} from 'lucide-react'
import { useAuth } from './hooks/useAuth'
import Dashboard from './pages/Dashboard'
import PacksPage from './pages/PacksPage'
import InventoryPage from './pages/InventoryPage'
import CatalogPage from './pages/CatalogPage'
import LeaderboardPage from './pages/LeaderboardPage'
import ActivityPage from './pages/ActivityPage'
import Landing from './pages/Landing'

const nav = [
  { to: '/app', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/app/packs', label: 'Packs', icon: Package },
  { to: '/app/inventory', label: 'Inventory', icon: Layers },
  { to: '/app/catalog', label: 'Catalog', icon: BookOpen },
  { to: '/app/leaderboard', label: 'Ranks', icon: Trophy },
  { to: '/app/activity', label: 'Activity', icon: Activity },
]

function Shell({ children }: { children: React.ReactNode }) {
  const { session, me, login, logout, loading } = useAuth()

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-navy-950/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-accent to-gold text-lg font-bold shadow-glow">
              ⚽
            </div>
            <div>
              <div className="font-display text-lg font-semibold leading-tight">Football DEX</div>
              <div className="text-xs text-white/50">Discord-synced collection</div>
            </div>
          </div>

          {session && (
            <nav className="hidden items-center gap-1 md:flex">
              {nav.map(({ to, label, icon: Icon }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/app'}
                  className={({ isActive }) =>
                    `flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${
                      isActive
                        ? 'bg-accent/20 text-accent-glow'
                        : 'text-white/60 hover:bg-white/5 hover:text-white'
                    }`
                  }
                >
                  <Icon size={16} />
                  {label}
                </NavLink>
              ))}
            </nav>
          )}

          <div className="flex items-center gap-3">
            {me && (
              <div className="hidden items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3 py-1.5 text-sm font-semibold text-gold sm:flex">
                <Coins size={14} />
                {me.footcoins.toLocaleString()}
              </div>
            )}
            {session ? (
              <button onClick={logout} className="btn-ghost text-sm">
                <LogOut size={16} />
                <span className="hidden sm:inline">{session.username || 'Logout'}</span>
              </button>
            ) : (
              <button onClick={login} className="btn-primary text-sm" disabled={loading}>
                <LogIn size={16} />
                Login with Discord
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8">{children}</main>

      <footer className="border-t border-white/5 py-6 text-center text-xs text-white/40">
        Same account as the Discord bot · inventory, packs & coins stay in sync
      </footer>
    </div>
  )
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { session, loading, login } = useAuth()
  if (loading) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center text-white/50">Loading…</div>
    )
  }
  if (!session) {
    return (
      <div className="glass mx-auto max-w-md rounded-2xl p-8 text-center animate-in">
        <h2 className="section-title mb-2">Sign in required</h2>
        <p className="mb-6 text-white/60">
          Log in with Discord to load your collection, open packs, and claim rewards — everything
          mirrors the bot.
        </p>
        <button onClick={login} className="btn-primary w-full">
          <LogIn size={18} /> Continue with Discord
        </button>
      </div>
    )
  }
  return <>{children}</>
}

export default function App() {
  return (
    <Shell>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route
          path="/app"
          element={
            <RequireAuth>
              <Dashboard />
            </RequireAuth>
          }
        />
        <Route
          path="/app/packs"
          element={
            <RequireAuth>
              <PacksPage />
            </RequireAuth>
          }
        />
        <Route
          path="/app/inventory"
          element={
            <RequireAuth>
              <InventoryPage />
            </RequireAuth>
          }
        />
        <Route
          path="/app/catalog"
          element={
            <RequireAuth>
              <CatalogPage />
            </RequireAuth>
          }
        />
        <Route
          path="/app/leaderboard"
          element={
            <RequireAuth>
              <LeaderboardPage />
            </RequireAuth>
          }
        />
        <Route
          path="/app/activity"
          element={
            <RequireAuth>
              <ActivityPage />
            </RequireAuth>
          }
        />
      </Routes>
    </Shell>
  )
}
