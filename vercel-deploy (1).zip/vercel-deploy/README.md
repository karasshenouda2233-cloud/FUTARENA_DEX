# Football Dex - Website (Vercel)

React + TypeScript + Vite frontend for Football Dex trading card game.

## Quick Start

1. **Install:** `npm install`
2. **Environment:** Create `.env.local` with:
   ```
   VITE_API_URL=https://your-bot-api.com
   ```
3. **Deploy:** `vercel deploy`

## Local Development

```bash
npm run dev
```

## Production Build

```bash
npm run build
```

## Vercel Configuration

- Build Command: `npm run build`
- Output Directory: `dist`
- Install Command: `npm install`

---
**Note:** Point `VITE_API_URL` to your WispByte bot API endpoint.
